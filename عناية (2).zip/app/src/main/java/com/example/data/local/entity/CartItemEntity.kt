package com.example.data.local.entity

import com.example.data.model.CartItem

/**
 * كيان سلة المشتريات لقاعدة بيانات Room
 * مسار الحزمة المخصص للكيانات المحلية: com.example.data.local.entity
 */
typealias CartItemEntity = CartItem
