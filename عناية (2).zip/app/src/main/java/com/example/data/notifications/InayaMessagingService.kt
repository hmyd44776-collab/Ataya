package com.example.data.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class InayaMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("InayaMessagingService", "FCM Device Token: $token")
        // Token can be sent to Firestore admin_devices collection or settings
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val orderId = remoteMessage.data["orderId"] ?: remoteMessage.notification?.title ?: ""
        val customerName = remoteMessage.data["customerName"] ?: "الزبون"
        val governorate = remoteMessage.data["governorate"] ?: ""
        val totalAmount = remoteMessage.data["totalAmount"] ?: ""

        val title = remoteMessage.notification?.title ?: "طلب جديد #$orderId"
        val body = remoteMessage.notification?.body ?: "طلب جديد من $customerName - $governorate"

        NotificationHelper.showOrderNotification(
            context = applicationContext,
            orderId = orderId,
            customerName = customerName,
            governorate = governorate,
            totalAmountFormatted = totalAmount.ifEmpty { body }
        )
    }
}
