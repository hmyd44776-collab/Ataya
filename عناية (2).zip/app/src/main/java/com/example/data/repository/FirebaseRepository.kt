package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.datasource.DefaultCatalog
import com.example.data.model.Category
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirebaseRepository(private val context: Context) {

    private val tag = "FirebaseRepository"

    private val isFirebaseAvailable: Boolean
        get() = try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (e: Exception) {
            false
        }

    private val firestore: FirebaseFirestore?
        get() = if (isFirebaseAvailable) {
            try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
        } else null

    private val auth: FirebaseAuth?
        get() = if (isFirebaseAvailable) {
            try { FirebaseAuth.getInstance() } catch (e: Exception) { null }
        } else null

    private val storage: FirebaseStorage?
        get() = if (isFirebaseAvailable) {
            try { FirebaseStorage.getInstance() } catch (e: Exception) { null }
        } else null

    // In-memory fallback caches if Firebase is not linked yet
    private var inMemoryCategories = DefaultCatalog.defaultCategories.toMutableList()
    private var inMemoryProducts = DefaultCatalog.defaultProducts.toMutableList()
    private var inMemoryOrders = mutableListOf<Order>()
    private var inMemorySettings = DefaultCatalog.defaultSettings
    private var inMemoryAdminLoggedIn = false

    // -------------------------------------------------------------
    // Store Settings
    // -------------------------------------------------------------
    fun getStoreSettings(): Flow<StoreSettings> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(inMemorySettings)
            awaitClose { }
            return@callbackFlow
        }

        val listener = db.collection("settings").document("store_settings")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Settings listener error: ${error.message}")
                    trySend(inMemorySettings)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val settings = StoreSettings(
                        storeName = snapshot.getString("storeName") ?: inMemorySettings.storeName,
                        deliveryFee = snapshot.getDouble("deliveryFee") ?: inMemorySettings.deliveryFee,
                        couponsEnabled = snapshot.getBoolean("couponsEnabled") ?: inMemorySettings.couponsEnabled,
                        adminUsername = snapshot.getString("adminUsername") ?: inMemorySettings.adminUsername,
                        adminPassword = snapshot.getString("adminPassword") ?: inMemorySettings.adminPassword
                    )
                    inMemorySettings = settings
                    trySend(settings)
                } else {
                    trySend(inMemorySettings)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateStoreSettings(settings: StoreSettings): Result<Unit> {
        inMemorySettings = settings
        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("settings").document("store_settings")
                .set(
                    mapOf(
                        "storeName" to settings.storeName,
                        "deliveryFee" to settings.deliveryFee,
                        "couponsEnabled" to settings.couponsEnabled,
                        "adminUsername" to settings.adminUsername,
                        "adminPassword" to settings.adminPassword
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Failed to update settings in Firestore: ${e.message}")
            Result.success(Unit) // Handled gracefully
        }
    }

    // -------------------------------------------------------------
    // Categories
    // -------------------------------------------------------------
    fun getCategories(): Flow<List<Category>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(inMemoryCategories.sortedBy { it.displayOrder })
            awaitClose { }
            return@callbackFlow
        }

        val listener = db.collection("categories")
            .orderBy("displayOrder", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Categories listener error: ${error.message}")
                    trySend(inMemoryCategories.sortedBy { it.displayOrder })
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Category::class.java)?.copy(id = doc.id)
                    }
                    inMemoryCategories = list.toMutableList()
                    trySend(list)
                } else {
                    // Seed initial categories to Firestore if empty and user has Firestore write access
                    trySend(inMemoryCategories.sortedBy { it.displayOrder })
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun addCategory(category: Category): Result<Unit> {
        val id = category.id.ifBlank { "cat_${System.currentTimeMillis()}" }
        val newCat = category.copy(id = id)
        inMemoryCategories.add(newCat)

        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("categories").document(id).set(newCat).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Failed to add category: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun updateCategory(category: Category): Result<Unit> {
        val index = inMemoryCategories.indexOfFirst { it.id == category.id }
        if (index != -1) inMemoryCategories[index] = category

        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("categories").document(category.id).set(category).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCategory(categoryId: String): Result<Unit> {
        inMemoryCategories.removeAll { it.id == categoryId }
        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("categories").document(categoryId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    // -------------------------------------------------------------
    // Products
    // -------------------------------------------------------------
    fun getProducts(): Flow<List<Product>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(inMemoryProducts)
            awaitClose { }
            return@callbackFlow
        }

        val listener = db.collection("products")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Products listener error: ${error.message}")
                    trySend(inMemoryProducts)
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Product::class.java)?.copy(id = doc.id)
                    }
                    inMemoryProducts = list.toMutableList()
                    trySend(list)
                } else {
                    trySend(inMemoryProducts)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun addProduct(product: Product): Result<Unit> {
        val id = product.id.ifBlank { "prod_${System.currentTimeMillis()}" }
        val newProd = product.copy(id = id)
        inMemoryProducts.add(0, newProd)

        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("products").document(id).set(newProd).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Failed to add product to Firestore: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun updateProduct(product: Product): Result<Unit> {
        val index = inMemoryProducts.indexOfFirst { it.id == product.id }
        if (index != -1) inMemoryProducts[index] = product

        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("products").document(product.id).set(product).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteProduct(productId: String): Result<Unit> {
        inMemoryProducts.removeAll { it.id == productId }
        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("products").document(productId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    // -------------------------------------------------------------
    // Orders
    // -------------------------------------------------------------
    fun getOrders(): Flow<List<Order>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(inMemoryOrders.sortedByDescending { it.createdAt })
            awaitClose { }
            return@callbackFlow
        }

        val listener = db.collection("orders")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Orders listener error: ${error.message}")
                    trySend(inMemoryOrders.sortedByDescending { it.createdAt })
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Order::class.java)?.copy(id = doc.id)
                    }
                    inMemoryOrders = list.toMutableList()
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun createOrder(order: Order): Result<String> {
        val generatedId = if (order.id.isNotBlank()) order.id else "ORD-${(1000..9999).random()}"
        val finalOrder = order.copy(
            id = generatedId,
            status = OrderStatus.ORDER_STATUS_NEW,
            createdAt = System.currentTimeMillis()
        )
        inMemoryOrders.add(0, finalOrder)

        val db = firestore
        if (db != null) {
            try {
                db.collection("orders").document(generatedId).set(finalOrder).await()
            } catch (e: Exception) {
                Log.w(tag, "Firestore order write fallback: ${e.message}")
            }
        }
        return Result.success(generatedId)
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String): Result<Unit> {
        val index = inMemoryOrders.indexOfFirst { it.id == orderId }
        if (index != -1) {
            inMemoryOrders[index] = inMemoryOrders[index].copy(status = newStatus)
        }

        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("orders").document(orderId).update("status", newStatus).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    // -------------------------------------------------------------
    // Image Upload (Firebase Storage)
    // -------------------------------------------------------------
    suspend fun uploadProductImage(imageUri: Uri): Result<String> {
        val stg = storage
        if (stg == null) {
            // Return Uri string directly for local display
            return Result.success(imageUri.toString())
        }
        return try {
            val fileName = "products/${UUID.randomUUID()}.jpg"
            val ref = stg.reference.child(fileName)
            ref.putFile(imageUri).await()
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.w(tag, "Storage upload fallback: ${e.message}")
            Result.success(imageUri.toString())
        }
    }

    // -------------------------------------------------------------
    // Admin Authentication
    // -------------------------------------------------------------
    fun isAdminLoggedIn(): Boolean {
        val firebaseUser = auth?.currentUser
        return firebaseUser != null || inMemoryAdminLoggedIn
    }

    suspend fun loginAdmin(usernameOrEmail: String, password: String): Result<Boolean> {
        val trimmed = usernameOrEmail.trim()
        val configuredUsername = inMemorySettings.adminUsername.trim()
        val configuredPassword = inMemorySettings.adminPassword

        // 1. التحقق من مطابقة اسم المستخدم/البريد وكلمة المرور المحددة من قبل صاحب المتجر
        val isUsernameMatch = trimmed.equals(configuredUsername, ignoreCase = true) ||
                (trimmed.contains("@") && trimmed.substringBefore("@").equals(configuredUsername, ignoreCase = true)) ||
                trimmed.equals("admin", ignoreCase = true) ||
                trimmed.equals("admin@inaya.store", ignoreCase = true)

        if (isUsernameMatch && password == configuredPassword) {
            inMemoryAdminLoggedIn = true
            return Result.success(true)
        }

        // 2. التحقق من Firebase Auth إذا كان بريداً مسجلاً
        val a = auth
        if (a != null && trimmed.contains("@")) {
            return try {
                a.signInWithEmailAndPassword(trimmed, password).await()
                inMemoryAdminLoggedIn = true
                Result.success(true)
            } catch (e: Exception) {
                Result.failure(Exception("اسم المستخدم أو كلمة المرور غير صحيحة"))
            }
        }

        return Result.failure(Exception("اسم المستخدم أو كلمة المرور غير صحيحة"))
    }

    fun logoutAdmin() {
        auth?.signOut()
        inMemoryAdminLoggedIn = false
    }

    // -------------------------------------------------------------
    // Coupons (Feature-flagged check)
    // -------------------------------------------------------------
    suspend fun validateCoupon(code: String): Result<Double> {
        val db = firestore
        val cleanCode = code.trim().uppercase()
        if (db == null) {
            // Fallback coupon for demo: SAVE10 gives 10%
            return if (cleanCode == "SAVE10" || cleanCode == "INAYA10") {
                Result.success(0.10) // 10%
            } else {
                Result.failure(Exception("الكوبون غير صالح أو منتهي الصلاحية"))
            }
        }

        return try {
            val doc = db.collection("coupons").document(cleanCode).get().await()
            if (doc.exists() && doc.getBoolean("isActive") == true) {
                val type = doc.getString("type") ?: "PERCENTAGE"
                val value = doc.getDouble("value") ?: 0.0
                val expiry = doc.getLong("expiryDate") ?: Long.MAX_VALUE
                if (System.currentTimeMillis() > expiry) {
                    Result.failure(Exception("هذا الكوبون منتهي الصلاحية"))
                } else {
                    Result.success(value)
                }
            } else {
                Result.failure(Exception("رمز الكوبون غير صحيح"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر التحقق من الكوبون حالياً"))
        }
    }
}
