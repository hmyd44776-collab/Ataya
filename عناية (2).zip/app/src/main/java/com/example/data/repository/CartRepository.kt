package com.example.data.repository

import com.example.data.local.CartDao
import com.example.data.model.CartItem
import kotlinx.coroutines.flow.Flow

class CartRepository(private val cartDao: CartDao) {

    val cartItems: Flow<List<CartItem>> = cartDao.getAllCartItems()

    suspend fun addToCart(productId: String, name: String, price: Double, imageUrl: String, quantity: Int = 1) {
        val existing = cartDao.getItemById(productId)
        if (existing != null) {
            cartDao.updateQuantity(productId, existing.quantity + quantity)
        } else {
            cartDao.insertOrUpdate(
                CartItem(
                    productId = productId,
                    name = name,
                    price = price,
                    imageUrl = imageUrl,
                    quantity = quantity
                )
            )
        }
    }

    suspend fun updateQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            cartDao.deleteItem(productId)
        } else {
            cartDao.updateQuantity(productId, quantity)
        }
    }

    suspend fun removeFromCart(productId: String) {
        cartDao.deleteItem(productId)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }
}
