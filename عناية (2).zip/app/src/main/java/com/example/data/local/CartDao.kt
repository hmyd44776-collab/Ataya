package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CartItem
import kotlinx.coroutines.flow.Flow

/**
 * واجهة الوصول للبيانات (DAO) لجدول السلة (cart_items).
 * تتيح تنفيذ كافة عمليات السلة باستخدام Kotlin Coroutines (دوال suspend و Flow)
 * لضمان أداء عالي وسلس بدون تجميد واجهة المستخدم (Non-blocking I/O).
 */
@Dao
interface CartDao {

    /**
     * 1. إضافة منتج إلى السلة أو تحديث بياناته في حال كان موجوداً مسبقاً.
     * تعمل كعملية غير متزامنة معلقة (suspend function) عبر Coroutines.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: CartItem)

    /**
     * إضافة منتج جديد إلى السلة.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addProduct(item: CartItem)

    /**
     * 2. تحديث كمية منتج محدد في السلة بالاعتماد على معرف المنتج (productId).
     */
    @Query("UPDATE cart_items SET quantity = :quantity WHERE product_id = :productId")
    suspend fun updateQuantity(productId: String, quantity: Int)

    /**
     * تحديث كائن المنتج بالكامل في السلة.
     */
    @Update
    suspend fun updateCartItem(item: CartItem)

    /**
     * 3. حذف منتج محدد من السلة باستخدام معرف المنتج (productId).
     */
    @Query("DELETE FROM cart_items WHERE product_id = :productId")
    suspend fun deleteItem(productId: String)

    /**
     * حذف عنصر السلة بتمرير كائن الكيان مباشرة.
     */
    @Delete
    suspend fun deleteItem(item: CartItem)

    /**
     * 4. حذف السلة بالكامل وتفريغ كافة محتوياتها (مثال: عند رغبة المستخدم أو بعد إتمام الطلب بنجاح).
     */
    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    /**
     * جلب جميع عناصر السلة مرتبة من الأحدث إلى الأقدم كـ Flow تفاعلي.
     * يُحدّث واجهة المستخدم تلقائياً عند أي تعديل في السلة.
     */
    @Query("SELECT * FROM cart_items ORDER BY added_at DESC")
    fun getAllCartItems(): Flow<List<CartItem>>

    /**
     * البحث عن منتج في السلة بواسطة معرفه للتحقق من وجوده وجلب بياناته الحالية.
     */
    @Query("SELECT * FROM cart_items WHERE product_id = :productId LIMIT 1")
    suspend fun getItemById(productId: String): CartItem?

    /**
     * احتساب إجمالي عدد القطع في السلة بشكل تفاعلي ومستمر.
     */
    @Query("SELECT COALESCE(SUM(quantity), 0) FROM cart_items")
    fun getTotalItemCount(): Flow<Int>

    /**
     * احتساب المجموع الإجمالي لأسعار منتجات السلة مباشرة من قاعدة البيانات.
     */
    @Query("SELECT COALESCE(SUM(price * quantity), 0.0) FROM cart_items")
    fun getSubtotal(): Flow<Double>
}
