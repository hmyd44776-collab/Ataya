package com.example.data.datasource

import com.example.data.model.Category
import com.example.data.model.Product
import com.example.data.model.StoreSettings

object DefaultCatalog {
    val defaultSettings = StoreSettings(
        storeName = "Glowcart",
        deliveryFee = 5000.0,
        couponsEnabled = false,
        adminUsername = "admin",
        adminPassword = "admin123456"
    )

    val defaultCategories = listOf(
        Category(
            id = "cat_skin",
            name = "العناية بالبشرة",
            imageUrl = "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&q=80",
            displayOrder = 1
        ),
        Category(
            id = "cat_hair",
            name = "العناية بالشعر",
            imageUrl = "https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?w=500&q=80",
            displayOrder = 2
        ),
        Category(
            id = "cat_body",
            name = "العناية بالجسم",
            imageUrl = "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=500&q=80",
            displayOrder = 3
        ),
        Category(
            id = "cat_perfume",
            name = "العطور والبخور",
            imageUrl = "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=500&q=80",
            displayOrder = 4
        ),
        Category(
            id = "cat_makeup",
            name = "المكياج والجمال",
            imageUrl = "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&q=80",
            displayOrder = 5
        )
    )

    val defaultProducts = listOf(
        // العناية بالبشرة
        Product(
            id = "prod_1",
            name = "سيروم فيتامين C",
            price = 25000.0,
            description = "سيروم مركز لتفتيح البشرة ومنحها نضارة...",
            categoryId = "cat_skin",
            imageUrl = "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_2",
            name = "كريم مرطب للوجه",
            price = 18000.0,
            description = "ترطيب عميق يدوم 24 ساعة لجميع أنواع...",
            categoryId = "cat_skin",
            imageUrl = "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_3",
            name = "واقي شمس شفاف SPF 50+",
            price = 25000.0,
            description = "حماية فائقة من أشعة الشمس فوق البنفسجية UVA/UVB بتركيبة خفيفة غير مرئية لا تترك طبقة بيضاء ومناسبة لجميع أنواع البشرة وتحت المكياج.",
            categoryId = "cat_skin",
            imageUrl = "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_4",
            name = "غسول رغوي لطيف بأحماض الفواكه",
            price = 14000.0,
            description = "ينظف المسام بعمق ويزيل الشوائب والزيوت الزائدة بلطف مع الحفاظ على التوازن الطبيعي لرطوبة البشرة.",
            categoryId = "cat_skin",
            imageUrl = "https://images.unsplash.com/photo-1556228722-d0b71946e39e?w=600&q=80",
            isAvailable = true
        ),

        // العناية بالشعر
        Product(
            id = "prod_5",
            name = "زيت الأرغان المغربي لإصلاح الشعر",
            price = 28000.0,
            description = "زيت علاجي نقي معصور على البارد يغذي أطراف الشعر المتقصفة، ويمنح خصلات الشعر لمعاناً حريرياً ويقضي على الهيشان والتطاير.",
            categoryId = "cat_hair",
            imageUrl = "https://images.unsplash.com/photo-1608248597359-598d9753e827?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_6",
            name = "ماسك الكيراتين والبروتين المكثف",
            price = 19000.0,
            description = "علاج أسبوعي عميق للشعر التالف والمعالج كيميائياً، يعيد بناء الروابط الداخلية للشعر ويتركه فائق النعومة وسهل التسريح.",
            categoryId = "cat_hair",
            imageUrl = "https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_7",
            name = "شامبو البيوتين لتقوية بصيلات الشعر",
            price = 16000.0,
            description = "خالٍ من الكبريتات والبارابين، يعزز نمو الشعر ويقلل من التساقط ويمنح فروة الرأس انتعاشاً وتنظيفاً متوازناً.",
            categoryId = "cat_hair",
            imageUrl = "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=600&q=80",
            isAvailable = true
        ),

        // العناية بالجسم
        Product(
            id = "prod_8",
            name = "مقشر السكر وزبدة الشيا بالفانيلا",
            price = 17500.0,
            description = "مقشر طبيعي فاخر يزيل خلايا الجلد الميتة بنعومة فائقة ويعيد للجسم نعومته المخملية مع رائحة فانيلا دافئة ومغرية.",
            categoryId = "cat_body",
            imageUrl = "https://images.unsplash.com/photo-1547887537-6158d64c35b3?w=600&q=80",
            isAvailable = true
        ),
        Product(
            id = "prod_9",
            name = "لوشن الجسم المركز بالمسك الأبيض",
            price = 21000.0,
            description = "لوشن مرطب غني بفيتامين E ومستخلصات زهرية، يمتص بسرعة ليعطي رائحة المسك النقية طوال 24 ساعة.",
            categoryId = "cat_body",
            imageUrl = "https://images.unsplash.com/photo-1617897903246-719242758050?w=600&q=80",
            isAvailable = true
        ),

        // العطور
        Product(
            id = "prod_10",
            name = "عطر الورد الدمشقي والعود الملكي",
            price = 45000.0,
            description = "توليفة شرقية راقية تجمع سحر بتلات الورد الدمشقي العطرية مع فخامة العود والعنبر الذهبي. ثبات وانتشار يدومان لأيام.",
            categoryId = "cat_perfume",
            imageUrl = "https://images.unsplash.com/photo-1594035910387-fea47794261f?w=600&q=80",
            isAvailable = true
        ),

        // المكياج
        Product(
            id = "prod_11",
            name = "أحمر شفاه مخملي مرطب - وردي نيود",
            price = 15000.0,
            description = "تركيبة مطفية مخملية غير جافة غنية بزيوت طبيعية تمنح الشفاه لوناً غنياً ثابتاً ومظهراً ممتلئاً.",
            categoryId = "cat_makeup",
            imageUrl = "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=600&q=80",
            isAvailable = true
        )
    )
}
