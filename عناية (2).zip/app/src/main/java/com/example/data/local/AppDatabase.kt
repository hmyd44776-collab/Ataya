package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CartItem

/**
 * فئة قاعدة بيانات Room الرئيسية للمتجر.
 * ترث من RoomDatabase وتعرف جدول السلة (CartItem) والـ DAO الخاص به (CartDao).
 */
@Database(
    entities = [CartItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    /**
     * واجهة الوصول لبيانات السلة (CartDao)
     */
    abstract fun cartDao(): CartDao

    companion object {
        const val DATABASE_NAME = "inaya_care_db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * دالة مصنع لبناء مثيل قاعدة البيانات مع تفعيل الترحيل التدميري الاحتياطي
         */
        fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
                .fallbackToDestructiveMigration()
                .build()
        }

        /**
         * نمط Singleton للحصول على مثيل قاعدة البيانات
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = buildDatabase(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
