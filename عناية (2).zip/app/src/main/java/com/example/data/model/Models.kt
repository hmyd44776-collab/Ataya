package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * تمثيل قسم من أقسام المتجر (عناية بالبشرة، العناية بالشعر، العطور، إلخ)
 */
data class Category(
    val id: String = "",
    val name: String = "",
    val imageUrl: String = "",
    val displayOrder: Int = 0
)

/**
 * تمثيل منتج العناية
 */
data class Product(
    val id: String = "",
    val name: String = "",
    val price: Double = 0.0,
    val description: String = "",
    val categoryId: String = "",
    val imageUrl: String = "",
    val isAvailable: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * كيان سلة المشتريات المحفوظة محلياً في قاعدة بيانات Room (CartItem Entity)
 * يضمن حفظ المنتجات وسعرها وكميتها مع وقت الإضافة
 */
@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey
    @ColumnInfo(name = "product_id")
    val productId: String,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "price")
    val price: Double,

    @ColumnInfo(name = "image_url")
    val imageUrl: String,

    @ColumnInfo(name = "quantity")
    val quantity: Int = 1,

    @ColumnInfo(name = "added_at")
    val addedAt: Long = System.currentTimeMillis()
) {
    /**
     * إجمالي سعر هذا المنتج في السلة (السعر × الكمية)
     */
    val totalPrice: Double
        get() = price * quantity

    /**
     * تحويل عنصر السلة إلى كائن طلب لـ Firestore
     */
    fun toOrderItemDto(): OrderItemDto = OrderItemDto(
        productId = productId,
        name = name,
        price = price,
        quantity = quantity,
        imageUrl = imageUrl
    )
}

/**
 * الاسم البديل المتوافق مع معايير Clean Architecture
 */
typealias CartItemEntity = CartItem

/**
 * كائن نقل بيانات عنصر الطلب للتخزين في Firestore
 */
data class OrderItemDto(
    val productId: String = "",
    val name: String = "",
    val price: Double = 0.0,
    val quantity: Int = 1,
    val imageUrl: String = ""
)

/**
 * تمثيل الطلب في Firestore
 */
data class Order(
    val id: String = "",
    val customerName: String = "",
    val governorate: String = "",
    val phoneNumber: String = "",
    val nearestLandmark: String = "",
    val notes: String = "",
    val items: List<OrderItemDto> = emptyList(),
    val subtotal: Double = 0.0,
    val discountAmount: Double = 0.0,
    val deliveryFee: Double = 5000.0,
    val totalAmount: Double = 0.0,
    val status: String = OrderStatus.ORDER_STATUS_NEW, // جديد، قيد التجهيز، تم التوصيل، ملغي
    val createdAt: Long = System.currentTimeMillis(),
    val paymentMethod: String = "الدفع عند الاستلام"
)

object OrderStatus {
    const val ORDER_STATUS_NEW = "جديد"
    const val ORDER_STATUS_PREPARING = "قيد التجهيز"
    const val ORDER_STATUS_DELIVERED = "تم التوصيل"
    const val ORDER_STATUS_CANCELLED = "ملغي"

    val allStatuses = listOf(
        ORDER_STATUS_NEW,
        ORDER_STATUS_PREPARING,
        ORDER_STATUS_DELIVERED,
        ORDER_STATUS_CANCELLED
    )
}

/**
 * إعدادات المتجر العامة
 */
data class StoreSettings(
    val storeName: String = "Glowcart",
    val deliveryFee: Double = 5000.0,
    val couponsEnabled: Boolean = false,
    val adminUsername: String = "admin",
    val adminPassword: String = "admin123456"
)

/**
 * كوبون الخصم
 */
data class Coupon(
    val code: String = "",
    val type: String = "PERCENTAGE", // "PERCENTAGE" أو "FIXED"
    val value: Double = 0.0,
    val expiryDate: Long = 0L,
    val usageLimit: Int = 100,
    val usageCount: Int = 0,
    val isActive: Boolean = true
)

/**
 * قائمة المحافظات العراقية الـ 18
 */
val IRAQI_GOVERNORATES = listOf(
    "بغداد",
    "البصرة",
    "نينوى",
    "أربيل",
    "السليمانية",
    "دهوك",
    "كركوك",
    "الأنبار",
    "ديالى",
    "صلاح الدين",
    "بابل",
    "كربلاء",
    "النجف",
    "واسط",
    "ذي قار",
    "ميسان",
    "المثنى",
    "القادسية"
)
