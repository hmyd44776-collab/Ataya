package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Category
import com.example.data.model.Product
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.InayaAsyncImage
import com.example.ui.theme.GlowcartCardBackground
import com.example.ui.theme.GlowcartCardBorder
import com.example.ui.theme.GlowcartCartGold
import com.example.ui.theme.GlowcartCartText
import com.example.ui.theme.GlowcartChipBg
import com.example.ui.theme.GlowcartChipText
import com.example.ui.theme.GlowcartGold
import com.example.ui.theme.GlowcartMaroon
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToCart: () -> Unit,
    onNavigateToAccount: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val storeSettings by viewModel.storeSettings.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryId.collectAsStateWithLifecycle()
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalCartCount = cartItems.sumOf { it.quantity }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.White,
        bottomBar = {
            // شريط التنقل السفلي المطابق للصورة
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, Color(0xFFF2ECEE))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. حسابي
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onNavigateToAccount)
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("nav_account")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Person,
                            contentDescription = "حسابي",
                            tint = Color(0xFF757575),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "حسابي",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF757575),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // 2. السلة (بلون الخردلي الذهبي المطابق للصورة)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onNavigateToCart)
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("nav_cart")
                    ) {
                        BadgedBox(
                            badge = {
                                if (totalCartCount > 0) {
                                    Badge(
                                        containerColor = GlowcartCartGold,
                                        contentColor = Color.White
                                    ) {
                                        Text(
                                            text = "$totalCartCount",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    // شارة دائرية خردلية صغيرة كما في الصورة
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(GlowcartCartGold)
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingCart,
                                contentDescription = "السلة",
                                tint = GlowcartCartGold,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "السلة",
                            style = MaterialTheme.typography.labelSmall,
                            color = GlowcartCartText,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 3. الرئيسية (النشطة باللون الماروني)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("nav_home")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "الرئيسية",
                            tint = GlowcartMaroon,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "الرئيسية",
                            style = MaterialTheme.typography.labelSmall,
                            color = GlowcartMaroon,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // شريط العنوان العلوي (Glowcart - منتجات العناية)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // أيقونة النجوم اللامعة على اليمين/اليسار
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(GlowcartChipBg)
                        .border(1.dp, GlowcartCardBorder, RoundedCornerShape(10.dp))
                        .clickable(onClick = onNavigateToAdmin)
                        .testTag("sparkle_admin_icon"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "لوحة التحكم",
                        tint = GlowcartMaroon,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // عنوان المتجر في الوسط تماماً
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Glowcart",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1A1A1A)
                    )
                    Text(
                        text = "منتجات العناية",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF757575)
                    )
                }

                // فراغ موازن لتوسيط العنوان تماماً
                Spacer(modifier = Modifier.size(38.dp))
            }

            // البانر الترويجي الفاخر بتدرج الماروني والبحث
            Card(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF450614),
                                    Color(0xFF6B1124),
                                    Color(0xFF75142B)
                                )
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 18.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // ✦ منتجات عناية أصلية 100% ✦
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "✦",
                                color = GlowcartGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "منتجات عناية أصلية 100%",
                                color = GlowcartGold,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "✦",
                                color = GlowcartGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // ✦ Glowcart
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "✦",
                                color = GlowcartGold,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Glowcart",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // الوصف المنسق
                        Text(
                            text = "كل ما تحتاجينه للعناية ببشرتك وشعرك – يوصل\nلباب بيتك",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFF3ECEE),
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // مربع البحث المدمج داخل البانر
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color.White.copy(alpha = 0.22f))
                                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "بحث",
                                    tint = Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))

                                BasicTextField(
                                    value = searchQuery,
                                    onValueChange = viewModel::onSearchQueryChange,
                                    singleLine = true,
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                                    cursorBrush = SolidColor(Color.White),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("search_text_field"),
                                    decorationBox = { innerTextField ->
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = "ابحثي عن منتج...",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = Color.White.copy(alpha = 0.75f)
                                            )
                                        }
                                        innerTextField()
                                    }
                                )

                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.onSearchQueryChange("") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "مسح",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // شريط الأقسام الأفقي (الكل - العناية بالبشرة - العناية بالشعر)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // تبويب "الكل"
                item {
                    val isAllSelected = selectedCategory == null
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = if (isAllSelected) GlowcartMaroon else GlowcartChipBg,
                        border = if (isAllSelected) null else BorderStroke(1.dp, GlowcartCardBorder),
                        modifier = Modifier
                            .clickable { viewModel.selectCategory(null) }
                            .testTag("category_chip_all")
                    ) {
                        Text(
                            text = "الكل",
                            color = if (isAllSelected) Color.White else GlowcartChipText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
                        )
                    }
                }

                // بقية الأقسام مع الأيقونات اللطيفة
                items(categories) { category ->
                    val isSelected = selectedCategory == category.id
                    val iconBadge = when (category.id) {
                        "cat_skin" -> " ✦"
                        "cat_hair" -> " 💄"
                        "cat_perfume" -> " ✨"
                        else -> ""
                    }
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = if (isSelected) GlowcartMaroon else GlowcartChipBg,
                        border = if (isSelected) null else BorderStroke(1.dp, GlowcartCardBorder),
                        modifier = Modifier
                            .clickable { viewModel.selectCategory(category.id) }
                            .testTag("category_chip_${category.id}")
                    ) {
                        Text(
                            text = "${category.name}$iconBadge",
                            color = if (isSelected) Color.White else GlowcartChipText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // شبكة المنتجات (عمودين متطابقين مع الصورة)
            if (products.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.ShoppingBag,
                    title = "لا توجد منتجات مطابقة",
                    subtitle = "جرّبي البحث باسم آخر أو اختيار قسم مختلف"
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("products_grid"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(products, key = { it.id }) { product ->
                        val itemInCart = cartItems.find { it.productId == product.id }
                        val cartQty = itemInCart?.quantity ?: 0

                        ProductGridItem(
                            product = product,
                            quantityInCart = cartQty,
                            onProductClick = { viewModel.openProductDetails(product) },
                            onAddToCart = { viewModel.addToCart(product, 1) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * بطاقة المنتج المطابقة تماماً لتصميم الصورة المرفقة
 */
@Composable
fun ProductGridItem(
    product: Product,
    quantityInCart: Int,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = GlowcartCardBackground
        ),
        border = BorderStroke(1.dp, GlowcartCardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onProductClick)
            .testTag("product_card_${product.id}")
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // صورة المنتج مع الشارة الدائرية للعدد إن وجد
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(14.dp))
            ) {
                InayaAsyncImage(
                    imageUrl = product.imageUrl,
                    contentDescription = product.name,
                    modifier = Modifier.fillMaxSize()
                )

                // الشارة الدائرية للكمية في السلة مثل الرقم (1) في الصورة
                if (quantityInCart > 0) {
                    Box(
                        modifier = Modifier
                            .padding(8.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(GlowcartMaroon)
                            .align(Alignment.TopEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$quantityInCart",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // حالة نفاد المخزون
                if (!product.isAvailable) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.error
                        ) {
                            Text(
                                text = "نفد من المخزون",
                                color = MaterialTheme.colorScheme.onError,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // اسم المنتج بخط عريض داكن مطابق للصورة
            Text(
                text = product.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // وصف مختصر من سطرين بلون رمادي
            Text(
                text = product.description,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF757575),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                minLines = 2,
                lineHeight = 16.sp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // السطر السفلي: السعر وزر الإضافة الماروني الصغير (+)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // زر الإضافة الماروني الصغير مع علامة +
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (product.isAvailable) GlowcartMaroon else Color.Gray)
                        .clickable(enabled = product.isAvailable, onClick = onAddToCart)
                        .testTag("add_to_cart_btn_${product.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة للسلة",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // السعر بالدينار العراقي بخط عريض
                Text(
                    text = FormatUtils.formatIqd(product.price),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF1A1A1A)
                )
            }
        }
    }
}
