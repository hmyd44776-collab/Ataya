package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.InayaApplication
import com.example.data.datasource.DefaultCatalog
import com.example.data.model.CartItem
import com.example.data.model.Category
import com.example.data.model.Order
import com.example.data.model.OrderItemDto
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.example.data.notifications.NotificationHelper
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class UiEvent {
    data class ShowToast(val message: String) : UiEvent()
    data class OrderSuccess(val orderId: String) : UiEvent()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val inayaApp = application as InayaApplication
    private val cartRepo = inayaApp.cartRepository
    private val firebaseRepo = inayaApp.firebaseRepository

    // Settings
    val storeSettings: StateFlow<StoreSettings> = firebaseRepo.getStoreSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DefaultCatalog.defaultSettings)

    // Categories
    val categories: StateFlow<List<Category>> = firebaseRepo.getCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DefaultCatalog.defaultCategories)

    // All Products
    val allProducts: StateFlow<List<Product>> = firebaseRepo.getProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DefaultCatalog.defaultProducts)

    // Search and Category Selection
    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    val selectedCategoryId: StateFlow<String?> = _selectedCategoryId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Filtered Products
    val filteredProducts: StateFlow<List<Product>> = combine(
        allProducts,
        selectedCategoryId,
        searchQuery
    ) { products, catId, query ->
        products.filter { product ->
            val matchesCategory = catId == null || product.categoryId == catId
            val matchesQuery = query.isBlank() || product.name.contains(query, ignoreCase = true) ||
                    product.description.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DefaultCatalog.defaultProducts)

    // Cart Items from Room
    val cartItems: StateFlow<List<CartItem>> = cartRepo.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart Calculations
    val cartSubtotal: StateFlow<Double> = cartItems.map { items ->
        items.sumOf { it.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    private val _discountRate = MutableStateFlow(0.0)
    val discountRate: StateFlow<Double> = _discountRate.asStateFlow()

    val discountAmount: StateFlow<Double> = combine(cartSubtotal, discountRate) { subtotal, rate ->
        subtotal * rate
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartTotal: StateFlow<Double> = combine(cartSubtotal, discountAmount, storeSettings) { subtotal, discount, settings ->
        if (subtotal == 0.0) 0.0 else (subtotal - discount + settings.deliveryFee).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Selected Product for Details Dialog
    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    // Admin State
    private val _isAdminLoggedIn = MutableStateFlow(firebaseRepo.isAdminLoggedIn())
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    val orders: StateFlow<List<Order>> = firebaseRepo.getOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedOrder = MutableStateFlow<Order?>(null)
    val selectedOrder: StateFlow<Order?> = _selectedOrder.asStateFlow()

    // UI Events
    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // -------------------------------------------------------------
    // Customer Interactions
    // -------------------------------------------------------------
    fun selectCategory(categoryId: String?) {
        _selectedCategoryId.value = categoryId
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun openProductDetails(product: Product) {
        _selectedProduct.value = product
    }

    fun closeProductDetails() {
        _selectedProduct.value = null
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        viewModelScope.launch {
            cartRepo.addToCart(
                productId = product.id,
                name = product.name,
                price = product.price,
                imageUrl = product.imageUrl,
                quantity = quantity
            )
            _events.emit(UiEvent.ShowToast("تمت إضافة \"${product.name}\" إلى السلة بنجاح"))
        }
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        viewModelScope.launch {
            cartRepo.updateQuantity(productId, quantity)
        }
    }

    fun removeFromCart(productId: String) {
        viewModelScope.launch {
            cartRepo.removeFromCart(productId)
            _events.emit(UiEvent.ShowToast("تم حذف المنتج من السلة"))
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            cartRepo.clearCart()
        }
    }

    fun applyCoupon(code: String) {
        if (!storeSettings.value.couponsEnabled) {
            viewModelScope.launch {
                _events.emit(UiEvent.ShowToast("نظام الكوبونات غير مفعّل حالياً من إدارة المتجر"))
            }
            return
        }

        if (code.isBlank()) {
            viewModelScope.launch {
                _events.emit(UiEvent.ShowToast("يرجى إدخال رمز الكوبون"))
            }
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            val result = firebaseRepo.validateCoupon(code)
            _isLoading.value = false
            if (result.isSuccess) {
                val rate = result.getOrNull() ?: 0.0
                _discountRate.value = rate
                val percent = (rate * 100).toInt()
                _events.emit(UiEvent.ShowToast("تم تطبيق كود الخصم بنجاح ($percent%)"))
            } else {
                val err = result.exceptionOrNull()
                _events.emit(UiEvent.ShowToast(err?.message ?: "كود الخصم غير صالح"))
            }
        }
    }

    fun placeOrder(
        customerName: String,
        governorate: String,
        phoneNumber: String,
        nearestLandmark: String,
        notes: String,
        onSuccess: (String) -> Unit
    ) {
        // Validation
        if (customerName.isBlank()) {
            emitToast("يرجى إدخال الاسم الكامل")
            return
        }
        if (governorate.isBlank()) {
            emitToast("يرجى اختيار المحافظة")
            return
        }
        if (!FormatUtils.isValidIraqiPhone(phoneNumber)) {
            emitToast("يرجى إدخال رقم هاتف عراقي صحيح (يبدأ بـ 07 ويتكون من 11 رقماً)")
            return
        }
        if (nearestLandmark.isBlank()) {
            emitToast("يرجى كتابة أقرب نقطة دالة لتسهيل التوصيل")
            return
        }
        val currentCart = cartItems.value
        if (currentCart.isEmpty()) {
            emitToast("السلة فارغة")
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            val itemsDto = currentCart.map {
                OrderItemDto(
                    productId = it.productId,
                    name = it.name,
                    price = it.price,
                    quantity = it.quantity,
                    imageUrl = it.imageUrl
                )
            }

            val order = Order(
                customerName = customerName.trim(),
                governorate = governorate,
                phoneNumber = phoneNumber.trim(),
                nearestLandmark = nearestLandmark.trim(),
                notes = notes.trim(),
                items = itemsDto,
                subtotal = cartSubtotal.value,
                discountAmount = discountAmount.value,
                deliveryFee = storeSettings.value.deliveryFee,
                totalAmount = cartTotal.value,
                status = OrderStatus.ORDER_STATUS_NEW,
                paymentMethod = "الدفع عند الاستلام"
            )

            val result = firebaseRepo.createOrder(order)
            _isLoading.value = false

            if (result.isSuccess) {
                val orderId = result.getOrNull() ?: "ORD-1000"
                // Clear Cart
                cartRepo.clearCart()
                _discountRate.value = 0.0

                // Trigger Local / FCM notification
                NotificationHelper.showOrderNotification(
                    context = getApplication(),
                    orderId = orderId,
                    customerName = order.customerName,
                    governorate = order.governorate,
                    totalAmountFormatted = FormatUtils.formatIqd(order.totalAmount)
                )

                _events.emit(UiEvent.OrderSuccess(orderId))
                onSuccess(orderId)
            } else {
                val err = result.exceptionOrNull()
                emitToast("حدث خطأ أثناء إتمام الطلب: ${err?.message}")
            }
        }
    }

    // -------------------------------------------------------------
    // Admin Operations
    // -------------------------------------------------------------
    fun loginAdmin(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = firebaseRepo.loginAdmin(email, pass)
            _isLoading.value = false
            if (res.isSuccess) {
                _isAdminLoggedIn.value = true
                emitToast("مرحباً بك في لوحة تحكم الأدمن")
                onSuccess()
            } else {
                val err = res.exceptionOrNull()
                emitToast(err?.message ?: "فشل تسجيل الدخول")
            }
        }
    }

    fun logoutAdmin() {
        firebaseRepo.logoutAdmin()
        _isAdminLoggedIn.value = false
        emitToast("تم تسجيل الخروج بنجاح")
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            firebaseRepo.updateOrderStatus(orderId, newStatus)
            emitToast("تم تغيير حالة الطلب إلى \"$newStatus\"")
        }
    }

    fun selectOrderForDetail(order: Order?) {
        _selectedOrder.value = order
    }

    fun saveCategory(category: Category, isNew: Boolean) {
        viewModelScope.launch {
            _isLoading.value = true
            if (isNew) {
                firebaseRepo.addCategory(category)
                emitToast("تمت إضافة القسم بنجاح")
            } else {
                firebaseRepo.updateCategory(category)
                emitToast("تم تعديل القسم بنجاح")
            }
            _isLoading.value = false
        }
    }

    fun deleteCategory(categoryId: String) {
        viewModelScope.launch {
            firebaseRepo.deleteCategory(categoryId)
            emitToast("تم حذف القسم")
        }
    }

    fun saveProduct(product: Product, isNew: Boolean, imageUri: Uri? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            var finalProduct = product
            if (imageUri != null) {
                val uploadResult = firebaseRepo.uploadProductImage(imageUri)
                if (uploadResult.isSuccess) {
                    val url = uploadResult.getOrNull()
                    if (url != null) {
                        finalProduct = finalProduct.copy(imageUrl = url)
                    }
                }
            }

            if (isNew) {
                firebaseRepo.addProduct(finalProduct)
                emitToast("تمت إضافة المنتج بنجاح")
            } else {
                firebaseRepo.updateProduct(finalProduct)
                emitToast("تم تعديل المنتج بنجاح")
            }
            _isLoading.value = false
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            firebaseRepo.deleteProduct(productId)
            emitToast("تم حذف المنتج")
        }
    }

    fun saveStoreSettings(settings: StoreSettings) {
        viewModelScope.launch {
            firebaseRepo.updateStoreSettings(settings)
            emitToast("تم حفظ إعدادات المتجر")
        }
    }

    private fun emitToast(msg: String) {
        viewModelScope.launch {
            _events.emit(UiEvent.ShowToast(msg))
        }
    }
}
