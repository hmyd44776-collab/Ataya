package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان متجر Glowcart الأصلية المطابقة للصورة المرفقة
val GlowcartMaroon = Color(0xFF6B1124)        // الماروني العنابي الفاخر للأزرار والأقسام والبانر
val GlowcartDarkMaroon = Color(0xFF4A0817)    // بداية تدرج البانر الداكن
val GlowcartBannerGradEnd = Color(0xFF73142D) // نهاية تدرج البانر
val GlowcartGold = Color(0xFFE5B567)          // نجوم الذهب والشارات ✦
val GlowcartCartGold = Color(0xFFBA8746)      // لون أيقونة وشارة سلة المشتريات الذهبي الخردلي المطابق للصورة تماماً
val GlowcartCartText = Color(0xFF7A6858)      // لون نص السلة المتناسق
val MaroonProductName = Color(0xFF1A1A1A)     // لون عنوان المنتج كما بالصورة (أسود داكن مائل للعنابي)

// ألوان الواجهة والبطاقات
val PureWhiteBackground = Color(0xFFFFFFFF)   // خلفية نقية بيضاء تماماً
val WhiteOnBackground = Color(0xFF1A1A1A)
val GlowcartCardBackground = Color(0xFFF9F6F7)// خلفية بطاقات المنتجات الهادئة
val GlowcartCardBorder = Color(0xFFECE3E5)    // حدود بطاقة المنتج الرقيقة
val GlowcartChipBg = Color(0xFFF2EBED)        // خلفية تبويب القسم غير النشط
val GlowcartChipText = Color(0xFF2A1C20)      // لون نص القسم غير النشط

val PinkPrimary = GlowcartMaroon              // اللون الأساسي هو الماروني الفاخر
val PinkOnPrimary = Color(0xFFFFFFFF)         // أبيض ناصع
val PinkContainer = Color(0xFFF7ECEF)
val PinkOnContainer = GlowcartMaroon

val PinkSecondary = GlowcartMaroon
val PinkOnSecondary = Color(0xFFFFFFFF)
val PinkSecondaryContainer = Color(0xFFFFFFFF)
val PinkOnSecondaryContainer = Color(0xFF1A1A1A)

val PinkTertiary = GlowcartGold
val PinkTertiaryContainer = Color(0xFFFFF6E6)
val PinkOnTertiaryContainer = Color(0xFF5A3E00)

val PureWhiteSurface = Color(0xFFFFFFFF)
val WhiteOnSurface = Color(0xFF1A1A1A)
val WhiteSurfaceVariant = Color(0xFFFBF8F9)
val WhiteOnSurfaceVariant = Color(0xFF706568)
val SubtleBorderOutline = Color(0xFFECE3E5)

// درجات النمط الداكن (Dark Theme)
val PinkDarkPrimary = Color(0xFFFF80AB)
val PinkDarkOnPrimary = Color(0xFF4A0021)
val PinkDarkContainer = Color(0xFF70133A)
val PinkDarkOnContainer = Color(0xFFFFD9E2)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkOnSurface = Color(0xFFF5F5F5)
val DarkSurfaceVariant = Color(0xFF2A2A2A)
val DarkOnSurfaceVariant = Color(0xFFCCCCCC)
val DarkOutline = Color(0xFF3E3E3E)
