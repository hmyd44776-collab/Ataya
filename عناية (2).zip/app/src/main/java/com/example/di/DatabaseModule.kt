package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.local.CartDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * وحدة Hilt لحقن قاعدة بيانات Room والـ DAO
 * (Hilt Database Module)
 * تضمن تزويد التطبيق بنسخة موحدة (Singleton) من AppDatabase و CartDao.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    /**
     * تزويد مثيل موحد (Singleton) من AppDatabase عبر حقن السياق (@ApplicationContext).
     */
    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            AppDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    /**
     * تزويد واجهة CartDao بالاعتماد على قاعدة البيانات المحقونة.
     */
    @Provides
    @Singleton
    fun provideCartDao(database: AppDatabase): CartDao {
        return database.cartDao()
    }
}
