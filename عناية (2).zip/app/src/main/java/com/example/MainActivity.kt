package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.UiEvent
import com.example.ui.components.ProductDetailSheet
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MyApplicationTheme

sealed class Screen {
    object Home : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    object Account : Screen()
    object AdminLogin : Screen()
    object AdminDashboard : Screen()
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialScreen = if (intent.getStringExtra("TARGET_SCREEN") == "ADMIN_ORDERS") {
            Screen.AdminDashboard
        } else {
            Screen.Home
        }

        setContent {
            MyApplicationTheme {
                MainAppContent(
                    viewModel = viewModel,
                    initialScreen = initialScreen
                )
            }
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: MainViewModel,
    initialScreen: Screen = Screen.Home
) {
    var currentScreen by remember { mutableStateOf(initialScreen) }
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    // Notification permission request for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Handled */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Observe ViewModel Events (Toast / Snackbars)
    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is UiEvent.ShowToast -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is UiEvent.OrderSuccess -> {
                    // Handled inside CheckoutScreen via dialog
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)

        when (currentScreen) {
            is Screen.Home -> {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCart = { currentScreen = Screen.Cart },
                    onNavigateToAccount = { currentScreen = Screen.Account },
                    onNavigateToAdmin = {
                        currentScreen = if (isAdminLoggedIn) {
                            Screen.AdminDashboard
                        } else {
                            Screen.AdminLogin
                        }
                    },
                    modifier = modifier
                )
            }

            is Screen.Account -> {
                AccountScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = Screen.Home },
                    onNavigateToAdmin = {
                        currentScreen = if (isAdminLoggedIn) {
                            Screen.AdminDashboard
                        } else {
                            Screen.AdminLogin
                        }
                    },
                    modifier = modifier
                )
            }

            is Screen.Cart -> {
                CartScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = Screen.Home },
                    onNavigateToCheckout = { currentScreen = Screen.Checkout },
                    modifier = modifier
                )
            }

            is Screen.Checkout -> {
                CheckoutScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = Screen.Cart },
                    onOrderPlacedSuccessfully = {
                        currentScreen = Screen.Home
                    },
                    modifier = modifier
                )
            }

            is Screen.AdminLogin -> {
                AdminLoginScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = Screen.Home },
                    onLoginSuccess = { currentScreen = Screen.AdminDashboard },
                    modifier = modifier
                )
            }

            is Screen.AdminDashboard -> {
                AdminDashboardScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = Screen.Home },
                    modifier = modifier
                )
            }
        }

        // تفاصيل المنتج المنبثقة
        selectedProduct?.let { product ->
            ProductDetailSheet(
                product = product,
                onDismiss = { viewModel.closeProductDetails() },
                onAddToCart = { prod, quantity ->
                    viewModel.addToCart(prod, quantity)
                }
            )
        }
    }
}
