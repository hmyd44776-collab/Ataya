package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.notifications.NotificationHelper
import com.example.data.repository.CartRepository
import com.example.data.repository.FirebaseRepository

class InayaApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var cartRepository: CartRepository
        private set

    lateinit var firebaseRepository: FirebaseRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getDatabase(this)
        cartRepository = CartRepository(database.cartDao())
        firebaseRepository = FirebaseRepository(this)

        NotificationHelper.createNotificationChannel(this)
    }

    companion object {
        lateinit var instance: InayaApplication
            private set
    }
}
