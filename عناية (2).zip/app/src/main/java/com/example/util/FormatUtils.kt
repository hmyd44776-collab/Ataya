package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object FormatUtils {
    private val iqdFormatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US))

    /**
     * تحويل المبلغ إلى صيغة الدينار العراقي مع فواصل الآلاف
     * مثال: 15000 -> 15,000 د.ع
     */
    fun formatIqd(amount: Double): String {
        return "${iqdFormatter.format(amount)} د.ع"
    }

    /**
     * التحقق من صيغة رقم الهاتف العراقي
     * يبدأ بـ 07 ويتكون من 11 رقماً
     */
    fun isValidIraqiPhone(phone: String): Boolean {
        val cleaned = phone.trim().replace(" ", "").replace("-", "")
        return cleaned.matches(Regex("^07[0-9]{9}$"))
    }
}
