package com.example

import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testIraqiPhoneValidation() {
        // Valid numbers: starts with 07 and 11 digits
        assertTrue(FormatUtils.isValidIraqiPhone("07701234567"))
        assertTrue(FormatUtils.isValidIraqiPhone("07809876543"))
        assertTrue(FormatUtils.isValidIraqiPhone("07501122334"))

        // Invalid numbers
        assertFalse(FormatUtils.isValidIraqiPhone("0770123456")) // 10 digits
        assertFalse(FormatUtils.isValidIraqiPhone("077012345678")) // 12 digits
        assertFalse(FormatUtils.isValidIraqiPhone("06701234567")) // starts with 06
        assertFalse(FormatUtils.isValidIraqiPhone("0770abc4567")) // letters
        assertFalse(FormatUtils.isValidIraqiPhone(""))
    }

    @Test
    fun testIqdFormatting() {
        assertEquals("15,000 د.ع", FormatUtils.formatIqd(15000.0))
        assertEquals("2,500 د.ع", FormatUtils.formatIqd(2500.0))
        assertEquals("120,000 د.ع", FormatUtils.formatIqd(120000.0))
    }
}
