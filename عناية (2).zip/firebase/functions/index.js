const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

/**
 * دالة سحابية تعمل تلقائياً عند إنشاء طلب جديد في Firestore
 * تقوم بإرسال إشعار فوري (FCM) للأدمن مع تفاصيل الطلب
 */
exports.sendOrderNotificationToAdmin = functions.firestore
  .document("orders/{orderId}")
  .onCreate(async (snap, context) => {
    const orderData = snap.data();
    const orderId = context.params.orderId;

    if (!orderData) {
      console.log("لا توجد بيانات للطلب");
      return null;
    }

    const customerName = orderData.customerName || "زبون";
    const governorate = orderData.governorate || "العراق";
    const totalAmount = orderData.totalAmount || 0;
    const formattedAmount = `${Number(totalAmount).toLocaleString("en-US")} د.ع`;

    const title = `طلب جديد #${orderId}`;
    const body = `طلب جديد من ${customerName} - ${governorate} - المجموع ${formattedAmount}`;

    const payload = {
      notification: {
        title: title,
        body: body,
      },
      data: {
        orderId: String(orderId),
        customerName: String(customerName),
        governorate: String(governorate),
        totalAmount: String(formattedAmount),
        click_action: "OPEN_ORDER_DETAILS",
      },
      android: {
        priority: "high",
        notification: {
          channelId: "inaya_orders_channel",
          sound: "default",
          priority: "max",
          visibility: "public",
        },
      },
      topic: "admin_orders", // يصل لجميع أجهزة المشرفين المشتركين بموضوع admin_orders
    };

    try {
      const response = await admin.messaging().send(payload);
      console.log(`تم إرسال إشعار الطلب #${orderId} بنجاح:`, response);
      return response;
    } catch (error) {
      console.error("فشل إرسال إشعار FCM للأدمن:", error);
      return null;
    }
  });

/**
 * دالة سحابية للتحقق الآمن من كوبونات الخصم ومنع التلاعب من جانب التطبيق
 */
exports.validateCoupon = functions.https.onCall(async (data, context) => {
  const code = (data.code || "").trim().toUpperCase();

  if (!code) {
    throw new functions.https.HttpsError("invalid-argument", "يرجى كتابة رمز الكوبون");
  }

  // 1. التحقق من تفعيل ميزة الكوبونات في إعدادات المتجر (Feature Flag)
  const settingsDoc = await db.collection("settings").document("store_settings").get();
  const couponsEnabled = settingsDoc.exists ? settingsDoc.data().couponsEnabled : false;

  if (!couponsEnabled) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "نظام الكوبونات غير مفعّل حالياً من إدارة المتجر"
    );
  }

  // 2. فحص الكوبون في مجموعة coupons
  const couponRef = db.collection("coupons").document(code);
  const couponDoc = await couponRef.get();

  if (!couponDoc.exists) {
    throw new functions.https.HttpsError("not-found", "رمز الكوبون غير صحيح");
  }

  const coupon = couponDoc.data();

  // فحص حالة الفعالية
  if (!coupon.isActive) {
    throw new functions.https.HttpsError("failed-precondition", "هذا الكوبون غير مفعّل");
  }

  // فحص تاريخ الصلاحية
  const now = Date.now();
  if (coupon.expiryDate && now > coupon.expiryDate) {
    throw new functions.https.HttpsError("failed-precondition", "عذراً، هذا الكوبون منتهي الصلاحية");
  }

  // فحص الحد الأقصى للاستخدام
  if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
    throw new functions.https.HttpsError("resource-exhausted", "تم استنفاد الحد الأقصى لاستخدام هذا الكوبون");
  }

  return {
    success: true,
    code: code,
    type: coupon.type || "PERCENTAGE", // "PERCENTAGE" أو "FIXED"
    value: coupon.value || 0,
    message: "تم تطبيق الكوبون بنجاح",
  };
});
